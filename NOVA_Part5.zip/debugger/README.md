# Debugger

Debugger architecture scaffold.
