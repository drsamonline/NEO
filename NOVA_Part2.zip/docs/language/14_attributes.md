# Attributes

Compile-time metadata.
