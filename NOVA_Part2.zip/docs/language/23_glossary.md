# Glossary

Core terminology.
