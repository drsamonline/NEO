Compiler module placeholder.
