Runtime module placeholder.
