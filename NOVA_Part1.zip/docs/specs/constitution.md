# Constitution

Intent over implementation.
