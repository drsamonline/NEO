# NOVA

Semantic Programming Platform

This repository contains the architecture and specifications for the NOVA project.
