Compiler test strategy.
