Benchmark strategy.
