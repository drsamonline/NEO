//! Lexer module scaffold
