//! Semantic IR scaffold
