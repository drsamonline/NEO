//! Parser module scaffold
