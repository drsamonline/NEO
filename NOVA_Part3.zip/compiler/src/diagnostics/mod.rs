//! Diagnostics scaffold
