//! Semantic analyzer scaffold
