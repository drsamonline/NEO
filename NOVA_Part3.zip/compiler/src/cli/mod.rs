//! CLI scaffold
