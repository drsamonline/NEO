# Compiler Architecture

Lexer -> Parser -> AST -> Semantic -> SIR -> Backend
