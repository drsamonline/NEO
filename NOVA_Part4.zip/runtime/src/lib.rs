//! NOVA runtime scaffold
